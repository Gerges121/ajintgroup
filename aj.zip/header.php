<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  * {
    font-family: 'satoshi', Tahoma;

  }
</style
<?php

wp_head(); ?>

<body class="<?php body_class(); ?>">

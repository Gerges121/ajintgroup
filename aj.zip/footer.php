</body>

<?php


wp_footer();

?>

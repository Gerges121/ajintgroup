
<div class="footerContainer">
    <div class="subContainer">
        <div class="leftSideForm">
            <form>
                <div class="nameInput">
                    <label>What is your name?</label>
                    <input placeholder="My name is...">
                </div>
                <div class="mobileInput">
                    <label>What is your mobile number?</label>
                    <div>
                        <select name="" class="countryCode">
                            <option>+966</option>
                            <option>+965</option>
                            <option>+964</option>
                        </select>
                        <input placeholder="12345678...">
                    </div>
                </div>
                <button class="formButton">CONTACT ME</button>
            </form>
        </div>
        <div class="rightMap">
            <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1801.3548534985014!2d55.51991!3d25.447967!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ef5f99473c8ed05%3A0xd2b8a7bdac97c982!2zQUogSW50ZXJuYXRpb25hbCBHcm91cCAtIFVBRSDZhdis2YXZiNi52Kkg2KPZitmHINis2YrZhyDYp9mE2K_ZiNmE2YrYqSDZhNmE2YXZhNin2KjYsyDYp9mE2YXYs9iq2LnZhdmE2Kk!5e0!3m2!1sen!2seg!4v1730811842407!5m2!1sen!2seg" width=100%  height=100% style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</div>

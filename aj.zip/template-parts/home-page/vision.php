  <div class="visionContainerLeft">
    <div class="leftSideC">
      <div class="leftSideImage">
        <img  src="<?php echo get_template_directory_uri(); ?>/src/img/ed2055253cc836b5e287ac7eb95d6ac7.png">

      </div>
      <div class="headingAndSubtitle">
        <h2>WHY WE ARE HERE</h2>
        <div class="separator"></div>
        <span>Recycling used and extra clothing to reduce textile waste in nature and its risks so we can reach clothes sustainability.</span>
      </div>
    </div>
  </div>
  <div class="visionContainerRight">
    <div class="rightSideC">
      <div class="headingAndSubtitle">
        <h2>WHAT TO ACHIEVE</h2>
        <div class="separator"></div>
        <span>We work on achieving the ease of contributing extra clothing through an integrated field and digital presence (depending on each country's demand policy), </span>
      </div>
      <div class="rightSideImage">
        <img  src="<?php echo get_template_directory_uri(); ?>/src/img/ed2055253cc836b5e287ac7eb95d6ac7.png">
      </div>
    </div>
  </div>

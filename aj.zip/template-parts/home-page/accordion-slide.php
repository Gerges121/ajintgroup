
<div class="accordionContainer">
  <div class="accordion">
    <div class="accordionItem">
      <div class="accordionContent" style="display: flex;"> <!-- Set display to block for the first item to be open by default -->
        <div class="heading">
          <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none">
            <circle cx="17" cy="17" r="5" fill="#BC6C25"/>
            <circle cx="17" cy="17" r="16.5" stroke="#BC6C25"/>
          </svg>
          <h2>INNOVATION</h2>
        </div>
        <div class="subtitle">
          <span>We track the latest methods to collect extra clothing and communicate with our customers in environmentally friendly and safe ways.</span>
        </div>
        <div class="lowerSlog">
          <h5>AJ VALUES</h5>
        </div>
      </div>
      <div class="accordionHeader" onclick="toggleAccordion(this)">SUSTAINABILITY 1</div>
    </div>
    <div class="accordionItem">
      <div class="accordionContent">
        <div class="heading">
          <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none">
            <circle cx="17" cy="17" r="5" fill="#BC6C25"/>
            <circle cx="17" cy="17" r="16.5" stroke="#BC6C25"/>
          </svg>
          <h2>INNOVATION</h2>
        </div>
        <div class="subtitle">
          <span>We track the latest methods to collect extra clothing and communicate with our customers in environmentally friendly and safe ways.</span>
        </div>
        <div class="lowerSlog">
          <h5>AJ VALUES</h5>
        </div>
      </div>
      <div class="accordionHeader" onclick="toggleAccordion(this)">SUSTAINABILITY 2</div>
    </div>
    <div class="accordionItem">
      <div class="accordionContent">
        <div class="heading">
          <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none">
            <circle cx="17" cy="17" r="5" fill="#BC6C25"/>
            <circle cx="17" cy="17" r="16.5" stroke="#BC6C25"/>
          </svg>
          <h2>INNOVATION</h2>
        </div>
        <div class="subtitle">
          <span>We track the latest methods to collect extra clothing and communicate with our customers in environmentally friendly and safe ways.</span>
        </div>
        <div class="lowerSlog">
          <h5>AJ VALUES</h5>
        </div>
      </div>
      <div class="accordionHeader" onclick="toggleAccordion(this)">SUSTAINABILITY 3</div>
    </div>
    <div class="accordionItem">
      <div class="accordionContent">
        <div class="heading">
          <svg xmlns="http://www.w3.org/2000/svg" width="34" height="34" viewBox="0 0 34 34" fill="none">
            <circle cx="17" cy="17" r="5" fill="#BC6C25"/>
            <circle cx="17" cy="17" r="16.5" stroke="#BC6C25"/>
          </svg>
          <h2>INNOVATION</h2>
        </div>
        <div class="subtitle">
          <span>We track the latest methods to collect extra clothing and communicate with our customers in environmentally friendly and safe ways.</span>
        </div>
        <div class="lowerSlog">
          <h5>AJ VALUES</h5>
        </div>
      </div>
      <div class="accordionHeader" onclick="toggleAccordion(this)">SUSTAINABILITY 4</div>
    </div>
  </div>
</div>

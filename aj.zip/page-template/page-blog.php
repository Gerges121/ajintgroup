<?php


/**
 * Template Name: Blog Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header();

get_template_part('template-parts/navbar/navbar');
get_template_part('template-parts/blog-page.php');


get_template_part('template-parts/footer/footer');
get_template_part('template-parts/footer/copyRights');

get_footer();


?>

<?php


/**
 * Template Name: Blog Page
 *
 * @package WordPress
 * @subpackage Twenty_Fourteen
 * @since Twenty Fourteen 1.0
 */

get_header();

get_template_part('template-parts/blog/blog-page');



get_footer();


?>

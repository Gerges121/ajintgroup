<?php

//Home Page

//require ('template-parts/navbar/navbar.php');
//require ('template-parts/home-page/home-page-hero.php');
//require ('template-parts/home-page/mission-section.php');
//require ('template-parts/home-page/vision.php');
//require ('template-parts/home-page/accordion-slide.php');
//require('template-parts/home-page/innovation-section.php');
//require('template-parts/home-page/news.php');
//require('template-parts/home-page/blogs.php');
//require ('template-parts/footer/footer.php');
//require ('template-parts/footer/copy-rights.php');

//Home Page







//Shop Page

//require ('template-parts/shop/shop-navbar.php');
//require ('template-parts/shop/product-search-bar.php');
//require ('template-parts/shop/genderCategories.php');
//require ('template-parts/shop/display-main-products.php');
//require ('template-parts/shop/shop-products.php');
//require ('template-parts/footer/footer.php');
//require ('template-parts/footer/copy-rights.php');

//Shop Page

//Product Page

//require ('template-parts/shop/shop-navbar.php');
//require ('template-parts/shop/product-search-bar.php');
//require ('template-parts/shop/product-page/product-details.php');
//require ('template-parts/shop/product-page/product-page.php');
//require ('template-parts/footer/footer.php');
//require ('template-parts/footer/copy-rights.php');

//Product Page



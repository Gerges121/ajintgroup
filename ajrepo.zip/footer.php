</body>

<footer>

  <?php get_template_part('template-parts/footer/footer'); ?>
  <?php get_template_part('template-parts/footer/copy-rights'); ?>
</footer>
<?php wp_footer(); ?>
</html>

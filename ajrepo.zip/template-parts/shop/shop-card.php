

  <div class="productCard">
    <img class="productImage" src="<?php echo get_template_directory_uri(); ?>/src/img/tshirtimg.webp" alt="Product Image" >

    <div class="productInfo">
      <h3 class="productName">Men’s T-Shirt black</h3>
      <p class="productPrice">24$</p>
    </div>
  </div>






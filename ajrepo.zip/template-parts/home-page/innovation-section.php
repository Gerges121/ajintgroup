

<div class="container">
  <div class="innovationContent" id="ourInnovations">

    <div class="innovationText">
      <h2>OUR INNOVATIVE
        CONTAINERS</h2>
      <p>AJ take steps towards the Environment, by collecting 300 tons of clothes daily and classify it to achieve sustainbility</p>

    </div>


    <div class="innovationImgAndButton">
      <img src="<?php echo get_template_directory_uri(); ?>/src/img/image5.png">
      <button>MORE INFO</button>
    </div>

  </div>
</div>



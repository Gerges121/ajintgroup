
<div class="container">
  <div class="missionSection" id="whatWeDo">
    <div class="missionHeaderPara">
      <h2>WHAT WE DO</h2>
      <p>AJ take steps towards the Environment, by collecting 300 tons of clothes daily and classify it to achieve sustainbility</p>
    </div>

    <div class="missionImgsContent">

      <div class="missionImgContent" onclick="toggleOpacity(this)">
        <img src="<?php echo get_template_directory_uri(); ?>/src/img/mission1.png">
        <div class="ImgContent">
          <h3>COLLECTING USED CLOTHES</h3>
          <p>used clothing in all countries of the world to reduce the risk of textile waste affecting</p>
        </div>
      </div>
      <div class="missionImgContent" onclick="toggleOpacity(this)">
        <img src="<?php echo get_template_directory_uri(); ?>/src/img/mission1.png">
        <div class="ImgContent">
          <h3>CLASSIFYING</h3>
          <p>used clothing in all countries of the world to reduce the risk of textile waste affectingc.</p>
        </div>
      </div>
      <div class="missionImgContent" onclick="toggleOpacity(this)">
        <img src="<?php echo get_template_directory_uri(); ?>/src/img/mission1.png">
        <div class="ImgContent">
          <h3>ACHIEVING SUSTAINABLITY</h3>
          <p>used clothing in all countries of the world to reduce the risk of textile waste affectingc.</p>
        </div>
      </div>



    </div>



  </div>



</div>
